# Server

This isn't the actual server used, I just decided to write it in Go after doing
the challenge because why the fuck not?
